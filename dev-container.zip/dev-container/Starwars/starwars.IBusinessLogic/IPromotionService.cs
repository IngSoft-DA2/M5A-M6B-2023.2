﻿using System;
namespace starwars.IBusinessLogic
{
    public interface IPromotionService
    {
        List<string> GetAllPromotions();
    }
}

