global using Microsoft.VisualStudio.TestTools.UnitTesting;
global using Moq;
global using starwars.Domain;
global using starwars.Domain.Enums;
global using starwars.IBusinessLogic;
global using starwars.BusinessLogic;