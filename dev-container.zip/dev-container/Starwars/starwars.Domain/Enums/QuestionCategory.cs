﻿using System;
namespace starwars.Domain.Enums
{
	public enum QuestionCategory
    {
        Peace,
        Diplomacy,
        Wisdom,
        Knowledge,
        Protection,
        HelpOthers,
        Power,
        Domination,
        Emotion,
        Passion,
        Individualism,
        Ambition,
        ConflictResolution,
        Cunning,
        AncientWisdom,
        Balance
    }
}

