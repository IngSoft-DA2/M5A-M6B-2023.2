﻿using System;
namespace starwars.Domain
{
	public class QuestionAnswer
	{
        public Question Question { get; set; }
        public bool AnswerValue { get; set; }
    }
}

