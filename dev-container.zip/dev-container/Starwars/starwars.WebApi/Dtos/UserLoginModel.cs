using System;

namespace starwars.WebApi.Dtos;
public class UserLoginModel
{
    public string Email { get; set; }
    public string Password { get; set; }
}

